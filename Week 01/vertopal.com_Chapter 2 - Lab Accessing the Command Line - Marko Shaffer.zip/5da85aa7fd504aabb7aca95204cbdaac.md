**Chapter 2: Lab Accessing the Command Line**

Marko Shaffer

Information Technology, Franklin University

ITEC 200: Linux Fundamentals

Professor Kagan Ulucay

5/28/2023

Red Hat System Administration I 8.2

Chapter 2 - Lab Accessing the Command Line

**Performance Checklist:**

In this lab, you will use the Bash shell to execute commands.

**Outcomes:**

- Successfully run simple programs using the Bash shell command line.

- Execute commands used to identify file types and display parts of text
  files.

- Practice using some Bash command history "shortcuts" to more
  efficiently repeat commands or parts of commands.

Log in to the workstation as username student using student as the
password.

|          | Franklin VM: | Standard User Account: | The Student's Root Account: |
|----------|--------------|------------------------|-----------------------------|
| Username | kiosk        | student                | root                        |
| Password | redhat       | student                | redhat                      |

On the workstation, run the **lab cli-review start** script to set up a
clean lab environment. The script also copies the zcat file to the
student's home directory.

**\[student@workstation \~\]\$ lab cli-review start**

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image1.png"
style="width:7.54417in;height:5.69357in" />

1.  Use the **date** command to display the current time and date.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image2.png"
style="width:7.54005in;height:5.75714in" />

2.  Display the current time in 12-hour clock time (for example,
    11:42:11 AM). Hint: The format string that displays that output
    is %r.

> Use the +%r argument with the **date** command to display the current
> time in 12-hour clock time.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image3.png"
style="width:7.51448in;height:5.71179in" />

3.  What kind of file is /home/student/zcat? Is it readable by humans?

> Use the **file** command to determine its file type.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image4.png"
style="width:7.61601in;height:5.76648in" />

4.  Use the **wc** command and Bash shortcuts to display the size
    of zcat.

> The **wc** command can be used to display the number of lines, words,
> and bytes in the zcat script. Instead of retyping the file name, use
> the Bash history shortcut **Esc**+**.** (the
> keys **Esc** and **.** pressed at the same time) to reuse the argument
> from the previous command.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image5.png"
style="width:7.56599in;height:5.70669in" />

5.  Display the first 10 lines of zcat.

> The **head** command displays the beginning of the file. Try using
> the **Esc**+**.** shortcut again.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image6.png"
style="width:7.46547in;height:5.6716in" />

6.  Display the last 10 lines of the zcat file.

> Use the **tail** command to display the last 10 lines of
> the zcat file.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image7.png"
style="width:7.56659in;height:5.65559in" />

7.  Repeat the previous command exactly with three or fewer keystrokes.

> Repeat the previous command exactly. Either press the **UpArrow** key
> once to scroll back through the command history one command and then
> press **Enter** (uses two keystrokes), or enter the shortcut
> command **!!** and then press **Enter** (uses three keystrokes) to run
> the most recent command in the command history . (Try both.)

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image8.png"
style="width:7.66242in;height:5.80162in" />

8.  Repeat the previous command, but use the -n 20 option to display the
    last 20 lines in the file. Use command-line editing to accomplish
    this with a minimal number of keystrokes.

> **UpArrow** displays the previous command. **Ctrl**+**A** makes the
> cursor jump to the beginning of the
> line. **Ctrl**+**RightArrow** jumps to the next word, then add the -n
> 20 option and hit **Enter** to execute the command.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image9.png"
style="width:7.63727in;height:5.73434in" />

9.  Use the shell history to run the **date +%r** command again.

> Use the **history** command to display the list of previous commands
> and to identify the specific **date** command to be executed.
> Use **!*number*** to run the command, where *number* is the command
> number to use from the output of the **history** command.
>
> Note that your shell history may be different from the following
> example. Determine the command number to use based on the output of
> your own **history** command.

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image10.png"
style="width:7.56789in;height:5.64953in" />

**Evaluation**

On workstation, run the **lab cli-review grade** script to confirm
success on this exercise.

**\[student@workstation \~\]\$ lab cli-review grade**

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image11.png"
style="width:7.58246in;height:5.72274in" />

**Finish**

On workstation, run the **lab cli-review finish** script to complete the
lab.

**\[student@workstation \~\]\$ lab cli-review finish**

<img src="vertopal_5da85aa7fd504aabb7aca95204cbdaac/media/image12.png"
style="width:7.51029in;height:5.55263in" />

This concludes the lab.
